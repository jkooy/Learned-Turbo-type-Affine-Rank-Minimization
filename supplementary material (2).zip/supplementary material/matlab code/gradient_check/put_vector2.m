function xs=put_vector2(n,index)
xs=zeros(n,1);
xs(index)=1;
end